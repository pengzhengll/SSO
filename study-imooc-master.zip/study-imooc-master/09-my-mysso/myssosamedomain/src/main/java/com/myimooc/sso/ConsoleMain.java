package com.myimooc.sso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsoleMain {

	public static void main(String[] args) {
		SpringApplication.run(ConsoleMain.class, args);
	}
}
