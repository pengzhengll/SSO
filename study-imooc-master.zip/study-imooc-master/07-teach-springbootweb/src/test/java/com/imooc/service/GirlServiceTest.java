package com.imooc.service;

import org.junit.Test;

/**
 * Created by 廖师兄
 * 2017-02-14 23:26
 */
public class GirlServiceTest {
    @Test
    public void findOne() throws Exception {

    }

}