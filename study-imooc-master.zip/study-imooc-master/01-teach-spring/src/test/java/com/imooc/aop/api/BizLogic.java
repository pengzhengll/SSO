package com.imooc.aop.api;

public interface BizLogic {
	
	String save();

}
