package com.imooc.ioc.injection.service;

public interface InjectionService {
	
	public void save(String arg);
	
}
