package com.imooc.beanannotation.javabased;

import com.imooc.spring.beanannotation.javabased.Store;

public class IntegerStore implements Store<Integer> {

}
