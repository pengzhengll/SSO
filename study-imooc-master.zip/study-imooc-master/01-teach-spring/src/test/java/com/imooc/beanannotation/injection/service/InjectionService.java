package com.imooc.beanannotation.injection.service;

public interface InjectionService {
	
	public void save(String arg);
	
}
