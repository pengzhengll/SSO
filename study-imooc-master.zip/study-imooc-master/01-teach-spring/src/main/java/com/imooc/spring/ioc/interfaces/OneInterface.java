package com.imooc.spring.ioc.interfaces;

public interface OneInterface {
	
	public void say(String arg);
	
}
