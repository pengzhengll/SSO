package com.imooc.spring.beanannotation.javabased;

public interface Store<T> {

}
