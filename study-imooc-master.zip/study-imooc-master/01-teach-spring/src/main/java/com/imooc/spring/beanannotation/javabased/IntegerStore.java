package com.imooc.spring.beanannotation.javabased;

import com.imooc.beanannotation.javabased.Store;

public class IntegerStore implements Store<Integer> {

}
