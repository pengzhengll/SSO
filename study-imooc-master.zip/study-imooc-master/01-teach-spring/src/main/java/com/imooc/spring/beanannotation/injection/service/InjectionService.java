package com.imooc.spring.beanannotation.injection.service;

public interface InjectionService {
	
	public void save(String arg);
	
}
