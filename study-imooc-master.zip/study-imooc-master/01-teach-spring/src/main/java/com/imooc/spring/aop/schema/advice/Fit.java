package com.imooc.spring.aop.schema.advice;

public interface Fit {
	
	void filter();

}
