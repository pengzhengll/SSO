package com.imooc.spring.bean;

public class BeanScope {
	
	public void say() {
		System.out.println("BeanScope say : " + this.hashCode());
	}
	
}
