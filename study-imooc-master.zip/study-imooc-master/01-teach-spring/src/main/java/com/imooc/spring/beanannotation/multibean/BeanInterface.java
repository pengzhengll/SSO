package com.imooc.spring.beanannotation.multibean;

public interface BeanInterface {

}
