package com.imooc.spring.ioc.injection.dao;

public interface InjectionDAO {
	
	public void save(String arg);
	
}
