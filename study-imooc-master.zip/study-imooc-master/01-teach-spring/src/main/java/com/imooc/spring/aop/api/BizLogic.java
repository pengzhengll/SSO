package com.imooc.spring.aop.api;

public interface BizLogic {
	
	String save();

}
