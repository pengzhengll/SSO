package com.myimooc.spring.ioc.injection.dao;

public interface InjectionDAO {
	
	public void save(String arg);
	
}
