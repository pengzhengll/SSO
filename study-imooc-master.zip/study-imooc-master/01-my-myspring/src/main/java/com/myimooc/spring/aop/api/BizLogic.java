package com.myimooc.spring.aop.api;

public interface BizLogic {
	
	String save();

}
