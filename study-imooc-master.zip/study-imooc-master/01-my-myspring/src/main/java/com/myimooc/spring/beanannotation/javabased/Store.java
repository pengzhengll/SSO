package com.myimooc.spring.beanannotation.javabased;

public interface Store<T> {

}
