package com.myimooc.spring.beanannotation.javabased;

public class IntegerStore implements Store<Integer> {

}
