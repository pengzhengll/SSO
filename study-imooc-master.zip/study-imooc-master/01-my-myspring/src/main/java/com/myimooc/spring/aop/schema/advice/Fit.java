package com.myimooc.spring.aop.schema.advice;

public interface Fit {
	
	void filter();

}
