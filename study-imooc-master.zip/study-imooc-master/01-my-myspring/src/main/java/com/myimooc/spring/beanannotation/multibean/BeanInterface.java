package com.myimooc.spring.beanannotation.multibean;

public interface BeanInterface {

}
