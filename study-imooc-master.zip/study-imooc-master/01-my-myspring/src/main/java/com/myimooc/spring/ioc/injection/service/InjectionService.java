package com.myimooc.spring.ioc.injection.service;

public interface InjectionService {
	
	public void save(String arg);
	
}
