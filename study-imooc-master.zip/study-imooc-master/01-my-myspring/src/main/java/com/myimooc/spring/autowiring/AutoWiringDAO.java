package com.myimooc.spring.autowiring;

public class AutoWiringDAO {
	
	public void say(String word) {
		System.out.println("AutoWiringDAO : " + word);
	}

}
