package com.myimooc.spring.ioc.interfaces;

public interface OneInterface {
	
	public void say(String arg);
	
}
