package com.myimooc.springboot.service;

/**
 * Created by ChengComputer on 2017/2/18.
 */
public interface GirlService {

    /**
     * 插入两个女生信息
     */
    void saveTwo();
}
